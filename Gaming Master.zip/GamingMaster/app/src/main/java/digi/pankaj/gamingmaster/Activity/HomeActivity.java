package digi.pankaj.gamingmaster.Activity;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Adapter;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.denzcoskun.imageslider.ImageSlider;
import com.denzcoskun.imageslider.constants.ScaleTypes;
import com.denzcoskun.imageslider.models.SlideModel;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

import digi.pankaj.gamingmaster.Adapter.RecyclerViewAdapter;
import digi.pankaj.gamingmaster.Helper.SharedPrefManager;
import digi.pankaj.gamingmaster.MainActivity;
import digi.pankaj.gamingmaster.Modal.RecyclerModal;
import digi.pankaj.gamingmaster.R;

public class HomeActivity extends AppCompatActivity {

    ImageSlider image_slider;

    DrawerLayout drawerLayout;

    MaterialToolbar toolbar;

    RecyclerView actionRecycler, racingRecycler, snackRecycler, cardRecycler, boardRecycler, bubbleRecycler, adventureRecycler;

    RecyclerViewAdapter actionAdapter, racingAdapter, snackAdapter, boardAdapter, bubbleAdapter, adventureAdapter;

    TextView nameOfUser;

    RelativeLayout logOut;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);


        actionRecycler = findViewById(R.id.actionRecycler);
        racingRecycler = findViewById(R.id.racingGame);
        snackRecycler = findViewById(R.id.snackGame);
        cardRecycler = findViewById(R.id.cardGame);
        boardRecycler = findViewById(R.id.boardGame);
        bubbleRecycler = findViewById(R.id.bubbleShooterGame);
        adventureRecycler = findViewById(R.id.adventureGame);
        nameOfUser = findViewById(R.id.nameOfUser);
        logOut = findViewById(R.id.logOut);

        nameOfUser.setText(SharedPrefManager.getInstance(HomeActivity.this).getUser().getName());

        logOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPrefManager.getInstance(HomeActivity.this).logout();
                startActivity(new Intent(HomeActivity.this, MainActivity.class));
            }
        });


        fetchFireBaseData();


        toolbar = findViewById(R.id.toolbar);


        toolbar.setOnMenuItemClickListener(new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {

                int id = item.getItemId();

                if (id == R.id.searchMenu) {
                    startActivity(new Intent(HomeActivity.this, SearchActivity.class));
                } else if (id == R.id.notificationMenu) {
                    Toast.makeText(HomeActivity.this, "Notification is not recieved", Toast.LENGTH_SHORT).show();
                }

                return true;
            }
        });
        image_slider = findViewById(R.id.image_slider);


        List<SlideModel> slideModelList = new ArrayList<>();

        slideModelList.add(new SlideModel("https://images-na.ssl-images-amazon.com/images/I/A1Mz43+3aEL.jpg", ScaleTypes.CENTER_CROP));
        slideModelList.add(new SlideModel("https://plays.org/screenshots/tom-and-jerry-run-jerry.png", ScaleTypes.CENTER_CROP));
        slideModelList.add(new SlideModel("https://sm.ign.com/t/ign_in/screenshot/default/ludo-king-sonu-sood-holi-2021_7u6x.2560.png", ScaleTypes.CENTER_CROP));
        slideModelList.add(new SlideModel("https://images.freecreatives.com/wp-content/uploads/2015/04/Video-Game-Desktop-Backgrounds-2.jpg", ScaleTypes.CENTER_CROP));

        image_slider.setImageList(slideModelList);
        drawerLayout = findViewById(R.id.drawerlayout);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawerLayout.openDrawer(GravityCompat.START);
            }
        });


    }

    void fetchFireBaseData() {
        Log.d("checkFirebaseData", "enter 1");
        List<RecyclerModal> actionRecyclerModalList = new ArrayList<>();
        List<RecyclerModal> reacingRecyclerModalList = new ArrayList<>();
        List<RecyclerModal> snackRecyclerModelList = new ArrayList<>();
        List<RecyclerModal> boardRecyclerModelList = new ArrayList<>();
        List<RecyclerModal> bubbleRecyclerModelList = new ArrayList<>();
        List<RecyclerModal> adventureAdapterModelList = new ArrayList<>();

        DatabaseReference dishRef = FirebaseDatabase.getInstance().getReference().child("users").child("game");

        dishRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                Log.d("checkFirebaseData", "onDataChange ");

                if (snapshot.exists()) {
                    Log.d("checkFirebaseData", "onDataChange exists");
                    for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                        String uniqueKey = dataSnapshot.getKey().toString();

                        Log.d("checkFirebaseData", "onDataChange " + uniqueKey);

                        dishRef.child(uniqueKey).addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot snapshot) {

                                if (snapshot.exists()) {
                                    Log.d("checkFirebaseData", "onDataChange snapshot is exists"+snapshot);
                                    RecyclerModal model = snapshot.getValue(RecyclerModal.class);

                                    if (model.getGameCategory().equalsIgnoreCase("Action")) {
                                        actionRecyclerModalList.add(model);
                                        actionAdapter.notifyDataSetChanged();
                                    } else if (model.getGameCategory().trim().equalsIgnoreCase("Racing")) {
                                        reacingRecyclerModalList.add(model);
                                        racingAdapter.notifyDataSetChanged();

                                    } else if (model.getGameCategory().trim().equalsIgnoreCase("Adventure")) {
                                        adventureAdapterModelList.add(model);
                                        adventureAdapter.notifyDataSetChanged();

                                    } else if (model.getGameCategory().trim().equalsIgnoreCase("Snake")) {
                                        snackRecyclerModelList.add(model);
                                        snackAdapter.notifyDataSetChanged();


                                    } else if (model.getGameCategory().trim().equalsIgnoreCase("Board")) {
                                        boardRecyclerModelList.add(model);
                                        boardAdapter.notifyDataSetChanged();


                                    } else if (model.getGameCategory().trim().equalsIgnoreCase("Bubble_Shooter")) {
                                        bubbleRecyclerModelList.add(model);
                                        bubbleAdapter.notifyDataSetChanged();

                                    } else {
                                        Log.d("checkFirebaseData", "snapshot not exists");
                                    }


                                }

                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {
                                Log.d("checkFirebaseData", "onCancelled error"+error.getMessage());
                            }
                        });

                    }

                    Log.d("checkFirebaseData", "action List size: "+actionRecyclerModalList.size());
                    actionAdapter = new RecyclerViewAdapter(actionRecyclerModalList, getApplicationContext());
                    actionRecycler.setAdapter(actionAdapter);
                    actionRecycler.setLayoutManager(new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.HORIZONTAL, false));

                    racingAdapter = new RecyclerViewAdapter(reacingRecyclerModalList, getApplicationContext());
                    racingRecycler.setAdapter(racingAdapter);
                    racingRecycler.setLayoutManager(new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.HORIZONTAL, false));

                    adventureAdapter = new RecyclerViewAdapter(adventureAdapterModelList, getApplicationContext());
                    adventureRecycler.setAdapter(adventureAdapter);
                    adventureRecycler.setLayoutManager(new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.HORIZONTAL, false));

                    snackAdapter = new RecyclerViewAdapter(snackRecyclerModelList, getApplicationContext());
                    snackRecycler.setAdapter(snackAdapter);
                    snackRecycler.setLayoutManager(new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.HORIZONTAL, false));

                    boardAdapter = new RecyclerViewAdapter(boardRecyclerModelList, getApplicationContext());
                    boardRecycler.setAdapter(boardAdapter);
                    boardRecycler.setLayoutManager(new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.HORIZONTAL, false));

                    bubbleAdapter = new RecyclerViewAdapter(bubbleRecyclerModelList, getApplicationContext());
                    bubbleRecycler.setAdapter(bubbleAdapter);
                    bubbleRecycler.setLayoutManager(new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.HORIZONTAL, false));


                }
                else {
                    Log.d("checkFirebaseData", "onDataChange snapshot not exists");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


    }

}


