package digi.pankaj.gamingmaster;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthOptions;
import com.google.firebase.auth.PhoneAuthProvider;

import java.util.concurrent.TimeUnit;

import digi.pankaj.gamingmaster.Activity.OtpActivity;

public class Registration extends AppCompatActivity {

    TextInputLayout registrationPhone, registrationName;

    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        registrationName = findViewById(R.id.registrationName);
        registrationPhone = findViewById(R.id.registrationPhone);
        button = findViewById(R.id.button);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                otpSendWtihFirebase(registrationPhone.getEditText().getText().toString(), OtpActivity.class);

            }
        });

    }

    public void otpSendWtihFirebase(String phoneNumber, Class context) {
        Log.d("PhoneNumberOtp", "otpSendWtihFirebase function call");
        Log.d("PhoneNumberOtp", "otpSendWtihFirebase : phoneNumber: " + phoneNumber);

        FirebaseAuth mAuth = FirebaseAuth.getInstance();
        PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallbacks = new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {

            @Override
            public void onVerificationCompleted(@NonNull PhoneAuthCredential credential) {

                Log.d("PhoneNumberOtp", "otpSendWtihFirebase : onVerificationCompleted: ");
                Log.d("PhoneNumberOtp", "otpSendWtihFirebase : onVerificationCompleted: credential: " + credential);
            }

            @Override
            public void onVerificationFailed(@NonNull FirebaseException e) {

                Log.d("PhoneNumberOtp", "otpSendWtihFirebase : onVerificationFailed: ");
                Log.d("PhoneNumberOtp", "otpSendWtihFirebase : onVerificationFailed: Exception: " + e.getLocalizedMessage());
            }

            @Override
            public void onCodeSent(@NonNull String verificationId,
                                   @NonNull PhoneAuthProvider.ForceResendingToken token) {
                // The SMS verification code has been sent to the provided phone number, we
                // now need to ask the user to enter the code and then construct a credential
                // by combining the code with a verification ID.
                //Log.d(TAG, "onCodeSent:" + verificationId);

                Log.d("PhoneNumberOtp", "otpSendWtihFirebase : onCodeSent: ");
                Log.d("PhoneNumberOtp", "otpSendWtihFirebase : onCodeSent: verificationId: " + verificationId);
                Log.d("PhoneNumberOtp", "otpSendWtihFirebase : onCodeSent: token: " + token);

                // Save verification ID and resending token so we can use them later
                Intent a = new Intent(Registration.this, context);
                a.putExtra("verificationId", verificationId);
                a.putExtra("token", token);
                a.putExtra("mobileNumber99", phoneNumber);
                a.putExtra("userName", registrationName.getEditText().getText().toString());
                a.putExtra("status89", "lg");
                startActivity(a);
                //mVerificationId = verificationId;
                //mResendToken = token;
            }
        };

        PhoneAuthOptions options =
                PhoneAuthOptions.newBuilder(mAuth)
                        .setPhoneNumber("+91" + phoneNumber)       // Phone number to verify
                        .setTimeout(60L, TimeUnit.SECONDS) // Timeout and unit
                        .setActivity(this)                 // (optional) Activity for callback binding
                        // If no activity is passed, reCAPTCHA verification can not be used.
                        .setCallbacks(mCallbacks)          // OnVerificationStateChangedCallbacks
                        .build();
        PhoneAuthProvider.verifyPhoneNumber(options);
    }
}