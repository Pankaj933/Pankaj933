package digi.pankaj.gamingmaster.Modal;

public class RecyclerModal {
    String gameCategory, gameName, gameUrl, gameImageUrl, gameMode, gameIconUrl;

    public RecyclerModal(String gameCategory, String gameName, String gameUrl, String gameImageUrl, String gameMode, String gameIconUrl) {
        this.gameCategory = gameCategory;
        this.gameName = gameName;
        this.gameUrl = gameUrl;
        this.gameImageUrl = gameImageUrl;
        this.gameMode = gameMode;
        this.gameIconUrl = gameIconUrl;
    }

    public String getGameCategory() {
        return gameCategory;
    }

    public void setGameCategory(String gameCategory) {
        this.gameCategory = gameCategory;
    }

    public String getGameName() {
        return gameName;
    }

    public void setGameName(String gameName) {
        this.gameName = gameName;
    }

    public String getGameUrl() {
        return gameUrl;
    }

    public void setGameUrl(String gameUrl) {
        this.gameUrl = gameUrl;
    }

    public String getGameImageUrl() {
        return gameImageUrl;
    }

    public void setGameImageUrl(String gameImageUrl) {
        this.gameImageUrl = gameImageUrl;
    }

    public String getGameMode() {
        return gameMode;
    }

    public void setGameMode(String gameMode) {
        this.gameMode = gameMode;
    }

    public String getGameIconUrl() {
        return gameIconUrl;
    }

    public void setGameIconUrl(String gameIconUrl) {
        this.gameIconUrl = gameIconUrl;
    }

    public RecyclerModal() {
    }
}
